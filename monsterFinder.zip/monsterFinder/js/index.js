import{ monsters } from "./monsters.js";

console.log(monsters);

for(let monster of monsters){
    showMonster(monster)
}

// showMonster()

function showMonster(monster){
    const monsterDiv=document.createElement('div');
    monsterDiv.className="monster";
    
    const img=document.createElement('img');
    // img.src=`https://robohash.org/${monster.id}?set=set2`;
    img.src=`https://robohash.org/${monster.id}?set=set2`;
    img.alt= monster.name;
    
    const email=document.createElement("p");
    email.className="email";
    email.innerText=monster.email;
    
    const name=document.createElement("h3");
    name.className="name";
    name.innerText=`${monster.name}`;
    
    monsterDiv.append(img,name,email);
    document.querySelector(".monsters").append(monsterDiv);

    console.log(monsterDiv);
};



notFound();
function notFound(){
    const notFoundDiv = document.createElement('div');
    notFoundDiv.className='not-found';
    notFoundDiv.style.display="none";

    const span = document.createElement('span');
    span.innerText="404";

    const h1 = document.createElement('h1');
    h1.innerText = 'NO master Found';
    notFoundDiv.append(span,h1);
    // notFoundDiv.append(h1)

    document.querySelector('.monsters').append(notFoundDiv);
    console.log(notFoundDiv)
}



document.querySelector('#searchMonster').addEventListener('keyup',function(e){

    const keyword = e.target.value.toLowerCase();
    const findmonsters = document.querySelectorAll('.monster')

    let nahimila = true;
    for(let monster of findmonsters){
        const name = monster.children[1].innerText.toLowerCase();
        const email = monster.children[2].innerText.toLowerCase();


        if(name.includes(keyword) || email.includes(keyword)){
            monster.style.display="block";
            nahimila = false;
        } 
        else{
            monster.style.display="none";
        }
        console.log(monster.children);
        console.log(name,email)
    }

    if(nahimila){
        document.querySelector('.not-found').style.display="block";
    }
    else{
        document.querySelector('.not-found').style.display="none";
    }

});

document.querySelector('#searchMonster').addEventListener('submit',e=>{
    e.preventDefault();
})
